import time

x = "BLUNT"     #If you want to change the word just change x, 
max_guesses = 6 #I would have added input for someonelese to type however,
guess_count = 0 #It would've been seen by the player.
won = False

print ("⬜ ⬜ ⬜")
time.sleep(0.5)
print ("⬜ 🟨 🟩")
time.sleep(0.5)
print ("🟩 🟩 🟩")
time.sleep(0.5)

Rules = input(" To play the game remember that for every letter\n (correct spot) = 🟩,\n (wrong spot) = 🟨,\n (not in word) = ⬛\nClick enter to proceed:")          

print ("⬜ ⬜ ⬜")
time.sleep(0.5)
print ("⬜ 🟨 🟩")
time.sleep(0.5)
print ("🟩 🟩 🟩")
time.sleep(0.5)

while guess_count < max_guesses and not won:
    guess = input(f" Guess a 5 letter word with\n with all uppercase letters, This counts toward {guess_count + 1}/6 guesses: ")

    # keep re-asking until the guess is valid without using up a real guess
    while len(guess) != 5 or not guess.isupper():
        if len(guess) != 5:
            guess = input(" You don't have 5 LETTERS\n The mistake does not count as a guess. Try Again: ")
        elif not guess.isupper():
            guess = input(" Please use ALL UPPERCASE letters\n The mistake does not count as a guess. Try Again: ")

    guess_count += 1

    if guess == x:
        won = True
        print(f"You got it! The word was {x}. You solved it in {guess_count}/6 guesses.")
    else:
        feedback = ""
        for i in range(5):
            letter = guess[i]
            if letter == x[i]:
                feedback += letter + "(🟩 ) "
            elif letter in x:
                feedback += letter + "(🟨 ) "
            else:
                feedback += letter + "(⬛ ) "
        print(feedback)

if not won:
    print(f" ❌❌ Out of guesses! The word was {x}.")